﻿' Purpose: To Dispaly a joke and punch line once the button is clicked
' Name: Djura Djurickovic 
'Date Sept 21 2011
'Authorship I Djura Djurickovic 000140392 certify that this material is
' my original work. Source code provided by the course text publisher was  
' modified entirely by me.  No other person's work has been used 
' without due acknowledgement. I have not made my work 
' available to anyone else.






Public Class frmLab2q7

    Private Sub btnSetup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSetup.Click
        'Displays label after button click 
        lblJoke.Visible = True
    End Sub

    Private Sub btnPunch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPunch.Click
        'Displays Label after button is clicked 
        lblJoke.Text = "None its a Hardware Problem"

        lblJoke.Visible = True



    End Sub
End Class