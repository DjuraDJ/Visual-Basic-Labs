﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSateLab2Q4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnVirginia = New System.Windows.Forms.Button()
        Me.btnNorthCarol = New System.Windows.Forms.Button()
        Me.btnSouthCarol = New System.Windows.Forms.Button()
        Me.btnGeorgia = New System.Windows.Forms.Button()
        Me.btnAlabam = New System.Windows.Forms.Button()
        Me.btnFlordia = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblAbbrev = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnVirginia
        '
        Me.btnVirginia.Location = New System.Drawing.Point(12, 147)
        Me.btnVirginia.Name = "btnVirginia"
        Me.btnVirginia.Size = New System.Drawing.Size(75, 35)
        Me.btnVirginia.TabIndex = 1
        Me.btnVirginia.Text = "Virginia"
        Me.btnVirginia.UseVisualStyleBackColor = True
        '
        'btnNorthCarol
        '
        Me.btnNorthCarol.Location = New System.Drawing.Point(93, 147)
        Me.btnNorthCarol.Name = "btnNorthCarol"
        Me.btnNorthCarol.Size = New System.Drawing.Size(75, 35)
        Me.btnNorthCarol.TabIndex = 2
        Me.btnNorthCarol.Text = "North Carolina"
        Me.btnNorthCarol.UseVisualStyleBackColor = True
        '
        'btnSouthCarol
        '
        Me.btnSouthCarol.Location = New System.Drawing.Point(174, 147)
        Me.btnSouthCarol.Name = "btnSouthCarol"
        Me.btnSouthCarol.Size = New System.Drawing.Size(75, 35)
        Me.btnSouthCarol.TabIndex = 3
        Me.btnSouthCarol.Text = "South Carolina"
        Me.btnSouthCarol.UseVisualStyleBackColor = True
        '
        'btnGeorgia
        '
        Me.btnGeorgia.Location = New System.Drawing.Point(12, 198)
        Me.btnGeorgia.Name = "btnGeorgia"
        Me.btnGeorgia.Size = New System.Drawing.Size(75, 23)
        Me.btnGeorgia.TabIndex = 4
        Me.btnGeorgia.Text = "Georgia"
        Me.btnGeorgia.UseVisualStyleBackColor = True
        '
        'btnAlabam
        '
        Me.btnAlabam.Location = New System.Drawing.Point(93, 198)
        Me.btnAlabam.Name = "btnAlabam"
        Me.btnAlabam.Size = New System.Drawing.Size(75, 23)
        Me.btnAlabam.TabIndex = 5
        Me.btnAlabam.Text = "Alabama"
        Me.btnAlabam.UseVisualStyleBackColor = True
        '
        'btnFlordia
        '
        Me.btnFlordia.Location = New System.Drawing.Point(174, 198)
        Me.btnFlordia.Name = "btnFlordia"
        Me.btnFlordia.Size = New System.Drawing.Size(75, 23)
        Me.btnFlordia.TabIndex = 6
        Me.btnFlordia.Text = "Florida"
        Me.btnFlordia.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(76, 227)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblAbbrev
        '
        Me.lblAbbrev.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAbbrev.Location = New System.Drawing.Point(46, 43)
        Me.lblAbbrev.Name = "lblAbbrev"
        Me.lblAbbrev.Size = New System.Drawing.Size(153, 77)
        Me.lblAbbrev.TabIndex = 8
        Me.lblAbbrev.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmSateLab2Q4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(303, 262)
        Me.Controls.Add(Me.lblAbbrev)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnFlordia)
        Me.Controls.Add(Me.btnAlabam)
        Me.Controls.Add(Me.btnGeorgia)
        Me.Controls.Add(Me.btnSouthCarol)
        Me.Controls.Add(Me.btnNorthCarol)
        Me.Controls.Add(Me.btnVirginia)
        Me.Name = "frmSateLab2Q4"
        Me.Text = "frmSateLab2Q4"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnVirginia As System.Windows.Forms.Button
    Friend WithEvents btnNorthCarol As System.Windows.Forms.Button
    Friend WithEvents btnSouthCarol As System.Windows.Forms.Button
    Friend WithEvents btnGeorgia As System.Windows.Forms.Button
    Friend WithEvents btnAlabam As System.Windows.Forms.Button
    Friend WithEvents btnFlordia As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblAbbrev As System.Windows.Forms.Label
End Class
