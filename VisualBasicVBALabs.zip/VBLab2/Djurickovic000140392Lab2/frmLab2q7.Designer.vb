﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLab2q7
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblJoke = New System.Windows.Forms.Label()
        Me.btnSetup = New System.Windows.Forms.Button()
        Me.btnPunch = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblJoke
        '
        Me.lblJoke.Location = New System.Drawing.Point(37, 41)
        Me.lblJoke.Name = "lblJoke"
        Me.lblJoke.Size = New System.Drawing.Size(165, 44)
        Me.lblJoke.TabIndex = 0
        Me.lblJoke.Text = "How many programers does it take to change a light bulb ?"
        Me.lblJoke.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblJoke.Visible = False
        '
        'btnSetup
        '
        Me.btnSetup.Location = New System.Drawing.Point(28, 123)
        Me.btnSetup.Name = "btnSetup"
        Me.btnSetup.Size = New System.Drawing.Size(75, 23)
        Me.btnSetup.TabIndex = 1
        Me.btnSetup.Text = "Setup"
        Me.btnSetup.UseVisualStyleBackColor = True
        '
        'btnPunch
        '
        Me.btnPunch.Location = New System.Drawing.Point(127, 123)
        Me.btnPunch.Name = "btnPunch"
        Me.btnPunch.Size = New System.Drawing.Size(75, 23)
        Me.btnPunch.TabIndex = 2
        Me.btnPunch.Text = "PunchLine"
        Me.btnPunch.UseVisualStyleBackColor = True
        '
        'frmLab2q7
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 262)
        Me.Controls.Add(Me.btnPunch)
        Me.Controls.Add(Me.btnSetup)
        Me.Controls.Add(Me.lblJoke)
        Me.Name = "frmLab2q7"
        Me.Text = "frmLab2q7"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lblJoke As System.Windows.Forms.Label
    Friend WithEvents btnSetup As System.Windows.Forms.Button
    Friend WithEvents btnPunch As System.Windows.Forms.Button
End Class
