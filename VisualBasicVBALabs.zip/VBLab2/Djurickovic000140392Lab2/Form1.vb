﻿'Purpose: To Dispaly the Name last name address and province on click
'Name: Djura Djurickovic 
'Date Sept 21 2011
'Authorship I Djura Djurickovic 000140392 certify that this material is
' my original work. Source code provided by the course text publisher was  
' modified entirely by me.  No other person's work has been used 
' without due acknowledgement. I have not made my work 
' available to anyone else.






Public Class frmNameAddress

    Private Sub btnShowInfo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShowInfo.Click
        'Displays name street city province postal code after button is clicked
        'Align all text to middle 
        lblName.TextAlign = ContentAlignment.MiddleCenter
        lblStreet.TextAlign = ContentAlignment.MiddleCenter
        lblCityStateZip.TextAlign = ContentAlignment.MiddleCenter

        lblName.Visible = True
        lblStreet.Visible = True
        lblCityStateZip.Visible = True


    End Sub

    Private Sub btnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExit.Click
        'close form 
        Me.Close()


    End Sub

   
End Class

