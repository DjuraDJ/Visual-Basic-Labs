﻿'Purpose: to Calculate child adult tickets prices after box office charge of 20 is given to distributors 
'I Djura Djurickovic 000140392 certify that this material is
'my original work. Source code provided by the course text publisher was  
'modified entirely by me.  No other person's work has been used 
'without due acknowledgement. I have not made my work 
'available to anyone else.






Public Class frmRevenue


    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        'close form
        Me.Close()
    End Sub

    Private Sub btnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClear.Click
        TxtAdultTick.Clear()
        TxtChildTick.Clear()           ' clears textboxs afte click
        TxtChildSold.Clear()
        TxtAdultSold.Clear()

        'give focus to Adult tickit
        TxtAdultTick.Focus()

    End Sub

    Private Sub btnCalc_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCalc.Click
        Dim DecAdultTickPrice As Decimal
        Dim DecChildticketPrice As Decimal
        Dim DecTotGross As Decimal
        Dim DecGrossAdultRate As Decimal               'decloration of variables used in program
        Dim DecGrossChildRate As Decimal
        Dim DecTotRev As Decimal
        Const BoxRate As Decimal = 0.2          'box office rate used in calulation child gross and adult gross * 20%


        Try
            DecAdultTickPrice = CDec(TxtAdultTick.Text) * CDec(TxtAdultSold.Text)   'adult tickets with tickets sold

            lblAdultGross.Text = DecAdultTickPrice.ToString("c")        'variable to string converstion 


            DecChildticketPrice = CDec(TxtChildTick.Text) * CDec(TxtChildSold.Text)         'child tickets with tickets sold 
            lblChildGross.Text = DecChildticketPrice.ToString("c")        'variable to string converstion  

            DecTotGross = CDec(lblChildGross.Text) + CDec(lblAdultGross.Text)      'adds gross to get total gross
            lblTotalGross.Text = DecTotGross.ToString("c")         'variable to string converstion 

            DecGrossAdultRate = CDec(lblAdultGross.Text) * BoxRate                   'multiplys Adult gross with box office rate 20%
            lblRvAdult.Text = DecGrossAdultRate.ToString("c")              'variable to string converstion 

            DecGrossChildRate = CDec(lblChildGross.Text) * BoxRate                       'multiplys child gross with box office rate 20%
            lblChildRev.Text = DecGrossChildRate.ToString("c")              'variable to string converstion 

            DecTotRev = CDec(lblChildRev.Text) + CDec(lblRvAdult.Text)              'add child rev and adult rev to get total rev
            lblTotalRevSales.Text = DecTotRev.ToString("c")                    'variable to string converstion 
        Catch
            MessageBox.Show("All input must be a Valid Numeric Value")   'displays msg if text box left blank


        End Try






    End Sub




    Private Sub frmRevenue_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MessageBox.Show("Prepare to see the Theatre  tickets!")
    End Sub
End Class