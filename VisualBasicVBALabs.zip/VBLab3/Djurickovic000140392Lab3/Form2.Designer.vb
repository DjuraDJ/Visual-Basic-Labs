﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmRevenue
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GrpbxAdultSales = New System.Windows.Forms.GroupBox()
        Me.TxtAdultSold = New System.Windows.Forms.TextBox()
        Me.TxtAdultTick = New System.Windows.Forms.TextBox()
        Me.lblTickSold = New System.Windows.Forms.Label()
        Me.lblAdPriceTick = New System.Windows.Forms.Label()
        Me.GrpBxChildSales = New System.Windows.Forms.GroupBox()
        Me.TxtChildSold = New System.Windows.Forms.TextBox()
        Me.TxtChildTick = New System.Windows.Forms.TextBox()
        Me.lblChildSold = New System.Windows.Forms.Label()
        Me.lblChildpriceperTick = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblTickSale = New System.Windows.Forms.Label()
        Me.lblChildTicSale = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTotGross = New System.Windows.Forms.Label()
        Me.GrpBxGrossRev = New System.Windows.Forms.GroupBox()
        Me.lblAdultGross = New System.Windows.Forms.Label()
        Me.lblTotalGross = New System.Windows.Forms.Label()
        Me.lblChildGross = New System.Windows.Forms.Label()
        Me.GrpbxTicRev = New System.Windows.Forms.GroupBox()
        Me.lblTotalRevSales = New System.Windows.Forms.Label()
        Me.lblChildRev = New System.Windows.Forms.Label()
        Me.lblRvAdult = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblAdultRevtick = New System.Windows.Forms.Label()
        Me.GrpbxAdultSales.SuspendLayout()
        Me.GrpBxChildSales.SuspendLayout()
        Me.GrpBxGrossRev.SuspendLayout()
        Me.GrpbxTicRev.SuspendLayout()
        Me.SuspendLayout()
        '
        'GrpbxAdultSales
        '
        Me.GrpbxAdultSales.Controls.Add(Me.TxtAdultSold)
        Me.GrpbxAdultSales.Controls.Add(Me.TxtAdultTick)
        Me.GrpbxAdultSales.Controls.Add(Me.lblTickSold)
        Me.GrpbxAdultSales.Controls.Add(Me.lblAdPriceTick)
        Me.GrpbxAdultSales.Location = New System.Drawing.Point(44, 41)
        Me.GrpbxAdultSales.Name = "GrpbxAdultSales"
        Me.GrpbxAdultSales.Size = New System.Drawing.Size(321, 190)
        Me.GrpbxAdultSales.TabIndex = 0
        Me.GrpbxAdultSales.TabStop = False
        Me.GrpbxAdultSales.Text = "Adult Ticket Sales"
        '
        'TxtAdultSold
        '
        Me.TxtAdultSold.Location = New System.Drawing.Point(119, 84)
        Me.TxtAdultSold.Name = "TxtAdultSold"
        Me.TxtAdultSold.Size = New System.Drawing.Size(104, 20)
        Me.TxtAdultSold.TabIndex = 3
        '
        'TxtAdultTick
        '
        Me.TxtAdultTick.Location = New System.Drawing.Point(119, 40)
        Me.TxtAdultTick.Name = "TxtAdultTick"
        Me.TxtAdultTick.Size = New System.Drawing.Size(104, 20)
        Me.TxtAdultTick.TabIndex = 2
        '
        'lblTickSold
        '
        Me.lblTickSold.AutoSize = True
        Me.lblTickSold.Location = New System.Drawing.Point(30, 91)
        Me.lblTickSold.Name = "lblTickSold"
        Me.lblTickSold.Size = New System.Drawing.Size(66, 13)
        Me.lblTickSold.TabIndex = 1
        Me.lblTickSold.Text = "Tickets Sold"
        '
        'lblAdPriceTick
        '
        Me.lblAdPriceTick.AutoSize = True
        Me.lblAdPriceTick.Location = New System.Drawing.Point(30, 40)
        Me.lblAdPriceTick.Name = "lblAdPriceTick"
        Me.lblAdPriceTick.Size = New System.Drawing.Size(83, 13)
        Me.lblAdPriceTick.TabIndex = 0
        Me.lblAdPriceTick.Text = "Price Per Ticket"
        '
        'GrpBxChildSales
        '
        Me.GrpBxChildSales.Controls.Add(Me.TxtChildSold)
        Me.GrpBxChildSales.Controls.Add(Me.TxtChildTick)
        Me.GrpBxChildSales.Controls.Add(Me.lblChildSold)
        Me.GrpBxChildSales.Controls.Add(Me.lblChildpriceperTick)
        Me.GrpBxChildSales.Location = New System.Drawing.Point(390, 41)
        Me.GrpBxChildSales.Name = "GrpBxChildSales"
        Me.GrpBxChildSales.Size = New System.Drawing.Size(335, 190)
        Me.GrpBxChildSales.TabIndex = 1
        Me.GrpBxChildSales.TabStop = False
        Me.GrpBxChildSales.Text = "Child Ticket Sales"
        '
        'TxtChildSold
        '
        Me.TxtChildSold.Location = New System.Drawing.Point(119, 84)
        Me.TxtChildSold.Name = "TxtChildSold"
        Me.TxtChildSold.Size = New System.Drawing.Size(104, 20)
        Me.TxtChildSold.TabIndex = 3
        '
        'TxtChildTick
        '
        Me.TxtChildTick.Location = New System.Drawing.Point(119, 40)
        Me.TxtChildTick.Name = "TxtChildTick"
        Me.TxtChildTick.Size = New System.Drawing.Size(104, 20)
        Me.TxtChildTick.TabIndex = 2
        '
        'lblChildSold
        '
        Me.lblChildSold.AutoSize = True
        Me.lblChildSold.Location = New System.Drawing.Point(30, 91)
        Me.lblChildSold.Name = "lblChildSold"
        Me.lblChildSold.Size = New System.Drawing.Size(66, 13)
        Me.lblChildSold.TabIndex = 1
        Me.lblChildSold.Text = "Tickets Sold"
        '
        'lblChildpriceperTick
        '
        Me.lblChildpriceperTick.AutoSize = True
        Me.lblChildpriceperTick.Location = New System.Drawing.Point(30, 40)
        Me.lblChildpriceperTick.Name = "lblChildpriceperTick"
        Me.lblChildpriceperTick.Size = New System.Drawing.Size(83, 13)
        Me.lblChildpriceperTick.TabIndex = 0
        Me.lblChildpriceperTick.Text = "Price Per Ticket"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(183, 598)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(139, 48)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate Ticket " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Revenue"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(352, 598)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(162, 48)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(538, 598)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(129, 48)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Exit"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblTickSale
        '
        Me.lblTickSale.AutoSize = True
        Me.lblTickSale.Location = New System.Drawing.Point(11, 45)
        Me.lblTickSale.Name = "lblTickSale"
        Me.lblTickSale.Size = New System.Drawing.Size(93, 13)
        Me.lblTickSale.TabIndex = 0
        Me.lblTickSale.Text = "Adult Ticket Sales"
        '
        'lblChildTicSale
        '
        Me.lblChildTicSale.AutoSize = True
        Me.lblChildTicSale.Location = New System.Drawing.Point(11, 92)
        Me.lblChildTicSale.Name = "lblChildTicSale"
        Me.lblChildTicSale.Size = New System.Drawing.Size(92, 13)
        Me.lblChildTicSale.TabIndex = 2
        Me.lblChildTicSale.Text = "Child Ticket Sales"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 151)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(61, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Total Gross"
        '
        'lblTotGross
        '
        Me.lblTotGross.AutoSize = True
        Me.lblTotGross.Location = New System.Drawing.Point(114, 151)
        Me.lblTotGross.Name = "lblTotGross"
        Me.lblTotGross.Size = New System.Drawing.Size(0, 13)
        Me.lblTotGross.TabIndex = 5
        '
        'GrpBxGrossRev
        '
        Me.GrpBxGrossRev.BackColor = System.Drawing.SystemColors.Control
        Me.GrpBxGrossRev.Controls.Add(Me.lblAdultGross)
        Me.GrpBxGrossRev.Controls.Add(Me.lblTotalGross)
        Me.GrpBxGrossRev.Controls.Add(Me.lblTotGross)
        Me.GrpBxGrossRev.Controls.Add(Me.Label5)
        Me.GrpBxGrossRev.Controls.Add(Me.lblChildGross)
        Me.GrpBxGrossRev.Controls.Add(Me.lblChildTicSale)
        Me.GrpBxGrossRev.Controls.Add(Me.lblTickSale)
        Me.GrpBxGrossRev.Location = New System.Drawing.Point(46, 256)
        Me.GrpBxGrossRev.Name = "GrpBxGrossRev"
        Me.GrpBxGrossRev.Size = New System.Drawing.Size(292, 268)
        Me.GrpBxGrossRev.TabIndex = 2
        Me.GrpBxGrossRev.TabStop = False
        Me.GrpBxGrossRev.Text = "Gross Ticket Revenue"
        '
        'lblAdultGross
        '
        Me.lblAdultGross.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblAdultGross.Location = New System.Drawing.Point(114, 33)
        Me.lblAdultGross.Name = "lblAdultGross"
        Me.lblAdultGross.Size = New System.Drawing.Size(107, 25)
        Me.lblAdultGross.TabIndex = 7
        Me.lblAdultGross.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblTotalGross
        '
        Me.lblTotalGross.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblTotalGross.Location = New System.Drawing.Point(114, 145)
        Me.lblTotalGross.Name = "lblTotalGross"
        Me.lblTotalGross.Size = New System.Drawing.Size(107, 25)
        Me.lblTotalGross.TabIndex = 6
        Me.lblTotalGross.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblChildGross
        '
        Me.lblChildGross.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblChildGross.Location = New System.Drawing.Point(114, 86)
        Me.lblChildGross.Name = "lblChildGross"
        Me.lblChildGross.Size = New System.Drawing.Size(107, 25)
        Me.lblChildGross.TabIndex = 3
        Me.lblChildGross.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GrpbxTicRev
        '
        Me.GrpbxTicRev.Controls.Add(Me.lblTotalRevSales)
        Me.GrpbxTicRev.Controls.Add(Me.lblChildRev)
        Me.GrpbxTicRev.Controls.Add(Me.lblRvAdult)
        Me.GrpbxTicRev.Controls.Add(Me.Label8)
        Me.GrpbxTicRev.Controls.Add(Me.Label10)
        Me.GrpbxTicRev.Controls.Add(Me.lblAdultRevtick)
        Me.GrpbxTicRev.Location = New System.Drawing.Point(390, 256)
        Me.GrpbxTicRev.Name = "GrpbxTicRev"
        Me.GrpbxTicRev.Size = New System.Drawing.Size(324, 268)
        Me.GrpbxTicRev.TabIndex = 6
        Me.GrpbxTicRev.TabStop = False
        Me.GrpbxTicRev.Text = "Net Ticket Revenue"
        '
        'lblTotalRevSales
        '
        Me.lblTotalRevSales.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblTotalRevSales.Location = New System.Drawing.Point(116, 154)
        Me.lblTotalRevSales.Name = "lblTotalRevSales"
        Me.lblTotalRevSales.Size = New System.Drawing.Size(107, 25)
        Me.lblTotalRevSales.TabIndex = 10
        Me.lblTotalRevSales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblChildRev
        '
        Me.lblChildRev.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblChildRev.Location = New System.Drawing.Point(116, 98)
        Me.lblChildRev.Name = "lblChildRev"
        Me.lblChildRev.Size = New System.Drawing.Size(107, 25)
        Me.lblChildRev.TabIndex = 9
        Me.lblChildRev.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblRvAdult
        '
        Me.lblRvAdult.BackColor = System.Drawing.SystemColors.ButtonShadow
        Me.lblRvAdult.Location = New System.Drawing.Point(116, 39)
        Me.lblRvAdult.Name = "lblRvAdult"
        Me.lblRvAdult.Size = New System.Drawing.Size(107, 25)
        Me.lblRvAdult.TabIndex = 8
        Me.lblRvAdult.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(14, 140)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(84, 39)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Total Net Revenue" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "for Ticket Sales :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 104)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(92, 13)
        Me.Label10.TabIndex = 2
        Me.Label10.Text = "Child Ticket Sales"
        '
        'lblAdultRevtick
        '
        Me.lblAdultRevtick.AutoSize = True
        Me.lblAdultRevtick.Location = New System.Drawing.Point(14, 51)
        Me.lblAdultRevtick.Name = "lblAdultRevtick"
        Me.lblAdultRevtick.Size = New System.Drawing.Size(96, 13)
        Me.lblAdultRevtick.TabIndex = 0
        Me.lblAdultRevtick.Text = "Adult Ticket Sales "
        '
        'frmRevenue
        '
        Me.AccessibleDescription = "Thus islabel"
        Me.AccessibleName = "ddhdhjf"
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(788, 708)
        Me.Controls.Add(Me.GrpbxTicRev)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GrpBxGrossRev)
        Me.Controls.Add(Me.GrpBxChildSales)
        Me.Controls.Add(Me.GrpbxAdultSales)
        Me.Name = "frmRevenue"
        Me.Text = "Theatre Revenue"
        Me.GrpbxAdultSales.ResumeLayout(False)
        Me.GrpbxAdultSales.PerformLayout()
        Me.GrpBxChildSales.ResumeLayout(False)
        Me.GrpBxChildSales.PerformLayout()
        Me.GrpBxGrossRev.ResumeLayout(False)
        Me.GrpBxGrossRev.PerformLayout()
        Me.GrpbxTicRev.ResumeLayout(False)
        Me.GrpbxTicRev.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GrpbxAdultSales As System.Windows.Forms.GroupBox
    Friend WithEvents TxtAdultSold As System.Windows.Forms.TextBox
    Friend WithEvents TxtAdultTick As System.Windows.Forms.TextBox
    Friend WithEvents lblTickSold As System.Windows.Forms.Label
    Friend WithEvents lblAdPriceTick As System.Windows.Forms.Label
    Friend WithEvents GrpBxChildSales As System.Windows.Forms.GroupBox
    Friend WithEvents TxtChildSold As System.Windows.Forms.TextBox
    Friend WithEvents TxtChildTick As System.Windows.Forms.TextBox
    Friend WithEvents lblChildSold As System.Windows.Forms.Label
    Friend WithEvents lblChildpriceperTick As System.Windows.Forms.Label
    Friend WithEvents btnCalc As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblTickSale As System.Windows.Forms.Label
    Friend WithEvents lblChildTicSale As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lblTotGross As System.Windows.Forms.Label
    Friend WithEvents GrpBxGrossRev As System.Windows.Forms.GroupBox
    Friend WithEvents GrpbxTicRev As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblAdultRevtick As System.Windows.Forms.Label
    Friend WithEvents lblTotalGross As System.Windows.Forms.Label
    Friend WithEvents lblAdultGross As System.Windows.Forms.Label
    Friend WithEvents lblChildGross As System.Windows.Forms.Label
    Friend WithEvents lblTotalRevSales As System.Windows.Forms.Label
    Friend WithEvents lblChildRev As System.Windows.Forms.Label
    Friend WithEvents lblRvAdult As System.Windows.Forms.Label
End Class
